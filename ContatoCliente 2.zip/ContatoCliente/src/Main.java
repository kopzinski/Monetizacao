
import java.util.List;
import javax.swing.JOptionPane;
import javax.ws.rs.core.GenericType;
import model.Cliente;
import ws.ClienteContato;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lhries
 */
public class Main {
    public static void main(String[] args) {
        ClienteContato cc = new ClienteContato();
        
        Cliente cliente = new Cliente(
                JOptionPane.showInputDialog("Nome: "),
                JOptionPane.showInputDialog("Email: "),
                JOptionPane.showInputDialog("CPF: "),
                null
            );
        //String contato = "{\"nome\":\"A\",\"email\":\"a@mail.com\"}";
        System.out.println(cliente);
        cc.adicionarContato(cliente);
        
        List<Cliente> contatos = cc.getContatos(new GenericType<List<Cliente>>(){});                        
        for(Cliente c: contatos)
            System.out.println(c);
        
    }
    
}
